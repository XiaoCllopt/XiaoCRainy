
package net.ccbluex.liquidbounce.api.minecraft.client.entity.player

enum class WEnumPlayerModelParts {
    CAPE,
    JACKET,
    LEFT_SLEEVE,
    RIGHT_SLEEVE,
    LEFT_PANTS_LEG,
    RIGHT_PANTS_LEG,
    HAT;
}