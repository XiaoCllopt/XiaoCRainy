
package net.ccbluex.liquidbounce.api.minecraft.client.renderer

interface IRenderGlobal {
    fun loadRenderers()
}