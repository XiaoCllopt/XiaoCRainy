
package net.ccbluex.liquidbounce.api.minecraft.scoreboard

interface IScore {
    val scorePoints: Int
    val playerName: String
}