
package net.ccbluex.liquidbounce.api.minecraft.world

interface IWorldSettings {

    enum class WGameType {
        NOT_SET,
        SURVIVAL,
        CREATIVE,
        ADVENTUR,
        SPECTATOR
    }

}