
package net.ccbluex.liquidbounce.api.enums

enum class WDefaultVertexFormats {
    POSITION, POSITION_TEX, POSITION_COLOR
}