
package net.ccbluex.liquidbounce.api.minecraft.client.gui.inventory

interface IIInventory {
    val name: String
}