package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.play.server.*
import net.minecraft.network.play.client.*
import net.minecraft.util.EnumFacing
import net.minecraft.util.math.BlockPos

@ModuleInfo(name = "HytVelocityFull", description = "FixFastBreak", category = ModuleCategory.HYT)
class HytVelocityFull : Module() {
    private val ticksValue = IntegerValue("Ticks",0,0,10)
    private val debugValue = BoolValue("Debug", true)
    private var tick = 0
    private var autoDis = 0

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if(autoDis > 0) {
            autoDis --
            return
        }
        val packet = event.packet.unwrap()
        if (packet is SPacketEntityVelocity && packet.entityID == mc!!.thePlayer!!.entityId) {
            event.cancelEvent()
            tick = ticksValue.get()
            if(debugValue.get()) {
                ClientUtils.displayChatMessage("Cancel S12")
            }
        }
        if(packet is SPacketPlayerPosLook) {
            autoDis = 10
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent){
        if(autoDis > 0) {
            return
        }
        if(tick > 0){
            tick --
            mc2.connection!!.networkManager.sendPacket(
                    CPacketPlayerDigging(
                            CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK,
                            BlockPos(mc2.player.posX, mc2.player.posY, mc2.player.posZ),
                            EnumFacing.UP
                    )
            )
            if(debugValue.get()) {
                ClientUtils.displayChatMessage("Send C07")
            }
        }
    }
}