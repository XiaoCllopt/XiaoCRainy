package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Sprint

@ModuleInfo(name = "ScaFix", description = "FixByXiaoC", category = ModuleCategory.HYT)
class ScaFix : Module() {
    override fun onDisable() {
        var sprintmodule = LiquidBounce.moduleManager.getModule(Sprint::class.java) as Sprint
        sprintmodule.state = true

    }
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        var sprintmodule = LiquidBounce.moduleManager.getModule(Sprint::class.java) as Sprint
        if (!mc.thePlayer!!.sneaking){
            if (mc.thePlayer!!.onGround){
                sprintmodule.state = true
            }else{
                sprintmodule.state = false
            }

        }
    }


}