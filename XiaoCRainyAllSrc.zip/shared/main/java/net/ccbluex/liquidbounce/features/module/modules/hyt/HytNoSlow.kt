package net.ccbluex.liquidbounce.features.module.modules.hyt

import XiaoC.utils.PacketUtils
import net.ccbluex.liquidbounce.api.enums.EnumFacingType
import net.ccbluex.liquidbounce.api.minecraft.item.IItem
import net.ccbluex.liquidbounce.api.minecraft.item.IItemStack
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.*
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.*
import java.util.*


@ModuleInfo(
        name = "HYTNoSlow", description = "Bypass Hyt",
        category = ModuleCategory.HYT

)
class HYTNoSlow : Module() {

    private val modeValue = ListValue(
            "PacketMode",
            arrayOf("Hyt-Normal","Hyt-Vanilla","Hyt-Fast","Hyt-Legit"),
            "Hyt-Vanilla"
    )
    private val timer = MSTimer()
    private var pendingFlagApplyPacket = false
    private val msTimer = MSTimer()
    private var sendBuf = false
    private var packetBuf = LinkedList<Packet<INetHandlerPlayServer>>()
    private var nextTemp = false
    private var waitC03 = false
    private var packet = 0
    override fun onDisable() {
        timer.reset()
        msTimer.reset()
        pendingFlagApplyPacket = false
        sendBuf = false
        packetBuf.clear()
        nextTemp = false
        waitC03 = false
    }
    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (!MovementUtils.isMoving) {
            return
        }
        when (modeValue.get().toLowerCase()) {
            "hyt-normal" -> {
                if ((event.eventState == EventState.PRE && mc.thePlayer!!.itemInUse != null && mc.thePlayer!!.itemInUse!!.item != null) && !mc.thePlayer!!.isBlocking && classProvider.isItemFood(
                                mc.thePlayer!!.heldItem!!.item
                        ) || classProvider.isItemPotion(mc.thePlayer!!.heldItem!!.item)
                ) {
                    if(mc.thePlayer!!.onGround){
                        if (mc.thePlayer!!.isUsingItem && mc.thePlayer!!.itemInUseCount >= 1) {
                            if(mc.thePlayer!!.sprinting){
                                if(!mc.thePlayer!!.onGround){
                                    mc.thePlayer!!.sprinting = false
                                }
                            }
                            if (mc.thePlayer!!.ticksExisted % 2 == 0) {
                                mc.thePlayer!!.sprinting = false
                            } else {
                                mc.thePlayer!!.sprinting = true
                            }
                            return
                        }
                    }
                }
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.timer.timerSpeed = 1.0F
                    mc.netHandler.addToSendQueue(
                            classProvider.createCPacketPlayerDigging(
                                    ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                                    WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                            )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
            "hyt-fast" -> {
                if((event.eventState == EventState.PRE && mc.thePlayer!!.itemInUse != null && mc.thePlayer!!.itemInUse!!.item != null) && !mc.thePlayer!!.isBlocking && classProvider.isItemFood(mc.thePlayer!!.heldItem!!.item) || classProvider.isItemPotion(mc.thePlayer!!.heldItem!!.item)){
                    if(mc.thePlayer!!.isUsingItem && mc.thePlayer!!.itemInUseCount >= 1){
                        if(mc.thePlayer!!.sprinting){
                            if(!mc.thePlayer!!.onGround){
                                mc.thePlayer!!.sprinting = false
                            }
                        }
                        if (packet != 16) {
                            if (mc.thePlayer!!.ticksExisted % 2 == 0) {
                                mc.thePlayer!!.sprinting = false
                                mc.timer.timerSpeed = 0.33f
                            }
                            else {
                                mc.thePlayer!!.sprinting = true
                                mc.timer.timerSpeed = 0.9F
                            }
                            PacketUtils.sendPacketNoEvent(CPacketPlayer(true))
                            return
                        }
                    }
                }
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.timer.timerSpeed = 1.0F
                    mc.netHandler.addToSendQueue(
                            classProvider.createCPacketPlayerDigging(
                                    ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                                    WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                            )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
            "hyt-legit" -> {
                if (event.eventState == EventState.PRE && classProvider.isItemSword(mc.thePlayer!!.heldItem!!.item)) {
                    mc.netHandler.addToSendQueue(
                            classProvider.createCPacketPlayerDigging(
                                    ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM,
                                    WBlockPos.ORIGIN, classProvider.getEnumFacing(EnumFacingType.DOWN)
                            )
                    )
                    mc.netHandler.addToSendQueue(classProvider.createCPacketPlayerBlockPlacement(mc.thePlayer!!.inventory.getCurrentItemInHand() as IItemStack))
                }
            }
            "hyt-vanilla" -> {
                mc.thePlayer!!.motionX *= 0.8F
                mc.thePlayer!!.motionY *= 0.8F
                mc.thePlayer!!.motionZ *= 0.8F
                mc.thePlayer!!.sprinting = true
            }
        }
    }
    @EventTarget
    fun onSlowDown(event: SlowDownEvent) {
        val heldItem = mc.thePlayer!!.heldItem?.item

        event.forward = getMultiplier(heldItem, true)
        event.strafe = getMultiplier(heldItem, false)
    }
    private fun getMultiplier(item: IItem?, isForward: Boolean): Float {
        if (modeValue.get() == "Hyt-Vanilla" ) {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 0.89999F else 0.999999F
                }

                else -> 0.2F
            }
        }
        if (modeValue.get() == "Hyt-Legit" ) {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }

                else -> 0.2F
            }
        }
        if (modeValue.get() == "Hyt-Normal" ) {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }
                else -> 0.6F
            }
        }
        if (modeValue.get() == "Hyt-Fast" ) {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }
                else -> 0.79F
            }
        }else {
            return when {
                classProvider.isItemSword(item) -> {
                    if (isForward) 1F else 1F
                }

                else -> 0F
            }
        }
    }
    override val tag: String
        get() = modeValue.get()

}


