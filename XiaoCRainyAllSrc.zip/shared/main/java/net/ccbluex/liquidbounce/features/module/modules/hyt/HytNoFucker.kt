package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.world.Fucker
import net.ccbluex.liquidbounce.utils.block.BlockUtils
import net.ccbluex.liquidbounce.utils.block.BlockUtils.getBlock
import net.ccbluex.liquidbounce.value.BlockValue

@ModuleInfo(name ="HytNoFucker", description = "CNM", category = ModuleCategory.HYT)
class HytNoFucker: Module(){
    private val blockValue = BlockValue("Block", 26)
    val targetId =blockValue.get()
    private var pos: WBlockPos? = null
    @EventTarget
    fun onUpdate(event: UpdateEvent){
        if(pos == null || functions.getIdFromBlock(getBlock(pos!!)!!) != targetId || BlockUtils.getCenterDistance(Fucker.pos!!) >7)
            pos = Fucker.find(targetId)
    }
}