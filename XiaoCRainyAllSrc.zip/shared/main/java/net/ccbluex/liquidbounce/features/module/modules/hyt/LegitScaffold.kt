/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.enums.BlockType
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.render.BlockOverlay
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.block.BlockUtils
import net.ccbluex.liquidbounce.utils.block.PlaceInfo
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import org.lwjgl.opengl.GL11
import java.awt.Color

@ModuleInfo(name = "LegitScaffold", category = ModuleCategory.HYT, description = "安全搭路")
class LegitScaffold : Module() {
    private val counterDisplayValue = BoolValue("Counter", true)
    private val markValue = BoolValue("Mark", true)
    private val test = BoolValue("test", true)
    private val walkbride = BoolValue("Walkbride", true)
    private val walkbrideValue = IntegerValue("walkbridedelay", 3, 1, 10)
    private val testValue = IntegerValue("testdelay", 3, 1, 10)
    private val autotimerValue = BoolValue("autotimer", true)
    private val speedValue = FloatValue("Speed", 2F, 0.1F, 10F)
    private val edgeValue = FloatValue("edgeRange", 0.25f, 0.01f, 2.0f)
    private val autopitch = FloatValue("Pitchvalue",80f, -180f, 180f)
    private val autoYaw = FloatValue("Yawvalue",0f, -180f, 180f)
    private val pitch = BoolValue("autoPitch", true)
    private val Yaw = BoolValue("autoYaw", false)
    var a = 0
    var b = 0

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val thePlayer = mc.thePlayer ?: return
        mc.gameSettings.keyBindSneak.pressed = mc.theWorld!!.getBlockState(WBlockPos(thePlayer.posX, thePlayer.posY - edgeValue.get().toDouble(), thePlayer.posZ)).block == classProvider.getBlockEnum(
                BlockType.AIR)
        if ((mc.objectMouseOver != null || mc.objectMouseOver!!.blockPos != null || mc.theWorld != null) &&
                classProvider.isItemBlock(mc.thePlayer!!.heldItem!!.item)) {
            if (pitch.get()) mc2.player.rotationPitch = autopitch.get()
            if (Yaw.get()) mc2.player.rotationPitch = autoYaw.get()
            mc.gameSettings.keyBindUseItem.pressed = mc.theWorld!!.getBlockState(mc.objectMouseOver!!.blockPos!!).block != classProvider.getBlockEnum(BlockType.AIR)
        }
        b += 1
        if (b >= testValue.get() && test.get() && (mc.gameSettings.keyBindSneak.isKeyDown || mc.thePlayer!!.sneaking) && (mc.gameSettings.keyBindUseItem.isKeyDown || mc.gameSettings.keyBindUseItem.pressed)) {
            mc.gameSettings.keyBindUseItem.pressed = true
            mc.gameSettings.keyBindSneak.pressed = false
            b = 0
        }
        if(walkbride.get() && mc.gameSettings.keyBindBack.isKeyDown){
            if (a <= walkbrideValue.get()) {
                a += 1
                mc.gameSettings.keyBindLeft.pressed = true
                mc.gameSettings.keyBindRight.pressed = false
            }else if(a <= (walkbrideValue.get()+walkbrideValue.get()+walkbrideValue.get())){
                a += 1
                mc.gameSettings.keyBindLeft.pressed = false
                mc.gameSettings.keyBindRight.pressed = true
            }else{
                a = -walkbrideValue.get()
            }
        }
        if (autotimerValue.get() && (mc.gameSettings.keyBindSneak.isKeyDown || mc.thePlayer!!.sneaking)) {
            mc.timer.timerSpeed = speedValue.get()
            return
        }
        mc.timer.timerSpeed = 1F
    }

    override fun onEnable() {
        a = 0
        b = 0
    }

    override fun onDisable() {
        if (mc.thePlayer == null)
            return

        if (!mc.gameSettings.isKeyDown(mc.gameSettings.keyBindSneak))
            mc.gameSettings.keyBindSneak.pressed = false
        if (!mc.gameSettings.isKeyDown(mc.gameSettings.keyBindUseItem))
            mc.gameSettings.keyBindUseItem.pressed = false
        if (!mc.gameSettings.isKeyDown(mc.gameSettings.keyBindLeft))
            mc.gameSettings.keyBindLeft.pressed = false
        if (!mc.gameSettings.isKeyDown(mc.gameSettings.keyBindRight))
            mc.gameSettings.keyBindRight.pressed = false
        mc.timer.timerSpeed = 1F
    }
    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        val player = mc.thePlayer ?: return
        if (!markValue.get()) {
            return
        }
        for (i in 0 until 2) {
            val yaw = Math.toRadians(player.rotationYaw.toDouble())
            val x = player.horizontalFacing.directionVec.x
            val z = player.horizontalFacing.directionVec.z
            val blockPos = WBlockPos(
                    player.posX + x * i,
                    player.posY - (if (player.posY == player.posY + 0.5) 0.0 else 1.0) - 0.0,
                    player.posZ + z * i
            )
            val placeInfo = PlaceInfo.get(blockPos)
            if (BlockUtils.isReplaceable(blockPos) && placeInfo != null) {
                RenderUtils.drawBlockBox(blockPos, Color(68, 117, 255, 100), false)
                break
            }
        }
    }

    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        if (counterDisplayValue.get()) {
            GL11.glPushMatrix()
            val blockOverlay = LiquidBounce.moduleManager.getModule(BlockOverlay::class.java) as BlockOverlay
            if (blockOverlay.state && blockOverlay.infoValue.get() && blockOverlay.currentBlock != null) {
                GL11.glTranslatef(0f, 15f, 0f)
            }
            val info = "Blocks: §7$blocksAmount"
            val scaledResolution = ScaledResolution(mc2)

            RenderUtils.drawBorderedRect(
                    scaledResolution.scaledWidth / 2 - 2.toFloat(),
                    scaledResolution.scaledHeight / 2 + 5.toFloat(),
                    scaledResolution.scaledWidth / 2 + Fonts.font40.getStringWidth(info) + 2.toFloat(),
                    scaledResolution.scaledHeight / 2 + 16.toFloat(),
                    3f,
                    Color.BLACK.rgb,
                    Color.BLACK.rgb
            )

            GlStateManager.resetColor()

            Fonts.font40.drawString(
                    info,
                    scaledResolution.scaledWidth / 2.toFloat(),
                    scaledResolution.scaledHeight / 2 + 7.toFloat(),
                    Color.WHITE.rgb
            )
            GL11.glPopMatrix()
        }
    }
    val blocksAmount: Int
        get() {
            var amount = 0
            for (i in 36..44) {
                val itemStack = mc.thePlayer!!.inventoryContainer.getSlot(i).stack
                if (itemStack != null && classProvider.isItemBlock(itemStack.item)) {
                    val block = itemStack.item!!.asItemBlock().block
                    val heldItem = mc.thePlayer!!.heldItem
                    if (heldItem != null && heldItem == itemStack || !InventoryUtils.BLOCK_BLACKLIST.contains(block) && !classProvider.isBlockBush(
                                    block
                            )
                    ) amount += itemStack.stackSize
                }
            }
            return amount
        }
    override val tag: String
        get() = "Ghost"
}
