package net.ccbluex.liquidbounce.features.command.commands

import XiaoC.auth.XiaoCAuth
import net.ccbluex.liquidbounce.LiquidBounce
import XiaoC.utils.QQUtils
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.features.module.modules.misc.XiaoChat
import net.ccbluex.liquidbounce.utils.misc.StringUtils
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class XiaoChatCommand : Command("irc") {

    private val xChat = LiquidBounce.moduleManager.getModule(XiaoChat::class.java) as XiaoChat
    val thePlayer = mc.thePlayer
    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        if (args.size > 1) {
            if (!xChat.state) {
                chat("§c错误：§7XiaoChat 已禁用！")
                return
            }


            val message = StringUtils.toCompleteString(args, 1)

            // 构造请求的 URL
            val qq = QQUtils.QQNumber ?: "NoLoginQQ" // 替换为您的 QQ 变量
            val cpuid = cpuid() // 替换为您的 cpuid 变量
            val gamename = mc.thePlayer!!.name ?: "UnknownPlayer" // 获取玩家自己的名字
            val url = "http://111.67.199.222:1314/irc.php?qq=$qq&cpuid=$cpuid&gamename=$gamename&msg=$message"

            if (gamename == "UnknownPlayer") {
                chat("§c错误：§7只允许在正确的环境下发送消息！")
                return
            }

            val response = sendHttpRequest(url)
            chat("§7[§a§lXiaoChat§7] §a消息已发送：$message")
        } else {
            chatSyntax("irc <消息>")
        }
    }
    fun cpuid(): String {
        val process = Runtime.getRuntime().exec(arrayOf("wmic", "cpu", "get", "ProcessorId"))
        process.outputStream.close()

        val sc = Scanner(process.inputStream)
        val cpuid = sc.next()

        return XiaoCAuth.md5(cpuid)
    }
    fun get(url: String): String {
        val con = URL(url).openConnection() as HttpURLConnection

        con.requestMethod = "GET"
        con.setRequestProperty("User-Agent", "Mozilla/5.0")

        val inStream = BufferedReader(InputStreamReader(con.inputStream))
        val response = StringBuilder()
        var inputLine: String?

        while (inStream.readLine().also { inputLine = it } != null) {
            response.append(inputLine)
        }

        inStream.close()
        return response.toString()
    }
    fun sendHttpRequest(url: String): String {
        return try {
            val response = URL(url).readText()
            response.trim()
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }
}
