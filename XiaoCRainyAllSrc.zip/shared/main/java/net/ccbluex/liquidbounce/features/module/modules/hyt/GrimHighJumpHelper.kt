package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo


@ModuleInfo(name="GrimHighJumpHelper",  description = "FixByXiaoC",  category = ModuleCategory.HYT)
class GrimHighJumpHelper : Module(){



    @EventTarget
    fun onUpdate(event: UpdateEvent) {


        val thePlayer = mc.thePlayer ?: return

        val grimHighJump = LiquidBounce.moduleManager.getModule(GrimHighJump::class.java) as GrimHighJump
        grimHighJump.state = !thePlayer.onGround

    }

override fun onDisable() {
    val grimHighJump = LiquidBounce.moduleManager.getModule(GrimHighJump::class.java) as GrimHighJump
    grimHighJump.state = false
}






















}