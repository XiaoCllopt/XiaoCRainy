/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.api.minecraft.util.IEnumFacing
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.injection.backend.utils.unwrap
import net.ccbluex.liquidbounce.utils.block.BlockUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.network.play.client.CPacketConfirmTransaction
import net.minecraft.network.play.client.CPacketPlayerDigging
import java.awt.Color

@ModuleInfo(name = "CivBreakFixed", description = "XiChenQi",category = ModuleCategory.HYT)
class CivBreakFixed : Module() {

    private var blockPos: WBlockPos? = null
    private var enumFacing: IEnumFacing? = null

    private val range = FloatValue("Range", 5F, 1F, 6F)

    var breaking = false
    var breakPercent = 0f

    var canBreak = false



    @EventTarget
    fun onBlockClick(event: ClickBlockEvent) {
        breaking = true

        blockPos = event.clickedBlock ?: return
        enumFacing = event.WEnumFacing ?: return
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (blockPos == null || enumFacing == null){
            return
        }

        if (breakPercent * 50 >= 100){
            canBreak = BlockUtils.getCenterDistance(blockPos!!) < range.get()
        } else {
            canBreak = false
        }

        if (canBreak){
            mc2.connection!!.networkManager.sendPacket(CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK,blockPos!!.unwrap(), enumFacing!!.unwrap()))
            blockPos = null
            enumFacing = null
            breaking = false
            breakPercent = 0f
        }

        if (breaking){
            breakPercent += mc2.world.getBlockState(blockPos!!.unwrap()).getPlayerRelativeBlockHardness(mc2.player,mc2.world,blockPos!!.unwrap())
        }
    }

    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        RenderUtils.drawBlockBox(blockPos ?: return, Color.BLUE, true)
    }
    @EventTarget
    fun onMotion(event: MotionEvent) {
        when (event.eventState) {
            EventState.POST -> {
                if (breaking) {
                    mc2.connection!!.networkManager.sendPacket(CPacketConfirmTransaction(0, 0, true))
                    mc.thePlayer!!.swingItem()
                }
            }
        }
    }
}