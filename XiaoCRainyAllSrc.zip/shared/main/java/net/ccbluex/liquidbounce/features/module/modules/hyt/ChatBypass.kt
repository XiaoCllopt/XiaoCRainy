package net.ccbluex.liquidbounce.features.module.modules.exploit

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "ChatBypass", description = "1dk", category = ModuleCategory.EXPLOIT)
class ChatBypass : Module() {
    private val modeValue = ListValue("Mode", arrayOf("HuaYuTing"), "HuaYuTing")

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (classProvider.isCPacketChatMessage(event.packet)) {

            val chatMessage = event.packet.asCPacketChatMessage()
            val message = chatMessage.message
            if (message.startsWith("/")) return
            val stringBuilder = StringBuilder()
            for (c in message.toCharArray())
                if (c.toInt() in 33..128)
                    stringBuilder.append(Character.toChars(c.toInt() + 65248)) else stringBuilder.append(c)
            chatMessage.message = "@$stringBuilder"
        }
    }
    override val tag: String
        get() = modeValue.get()
}