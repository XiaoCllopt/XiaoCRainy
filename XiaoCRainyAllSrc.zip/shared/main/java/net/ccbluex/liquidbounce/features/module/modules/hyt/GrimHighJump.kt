package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.event.EventState
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MotionEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(name = "GrimHighJump", description = "Grim漏洞", category = ModuleCategory.HYT)
class GrimHighJump : Module() {

    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (event.eventState == EventState.PRE) {
            mc.thePlayer!!.setPositionAndRotation(
                mc.thePlayer!!.posX + 1000,
                mc.thePlayer!!.posY,
                mc.thePlayer!!.posZ,
                mc.thePlayer!!.rotationYaw,
                mc.thePlayer!!.rotationPitch
            );
        } else {
            mc.thePlayer!!.setPositionAndRotation(
                mc.thePlayer!!.posX - 1000,
                mc.thePlayer!!.posY,
                mc.thePlayer!!.posZ,
                mc.thePlayer!!.rotationYaw,
                mc.thePlayer!!.rotationPitch
            );
        }
    }
    override val tag: String?
        get() = "Bypass"
}