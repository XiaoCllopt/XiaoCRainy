package net.ccbluex.liquidbounce.features.module.modules.hyt

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name = "HytRange", description = "Lower box", category = ModuleCategory.HYT)
class HytRange : Module() {

    //mixin
    val sizeValue = -0.5F

    override val tag: String?
        get() = "Grim"
}