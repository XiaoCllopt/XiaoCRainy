package net.ccbluex.liquidbounce.features.command.commands

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonSyntaxException
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.features.special.AntiForge
import net.ccbluex.liquidbounce.features.special.AutoReconnect.delay
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof
import net.ccbluex.liquidbounce.ui.client.altmanager.sub.altgenerator.GuiTheAltening.Companion.apiKey
import net.ccbluex.liquidbounce.utils.EntityUtils
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL

/**
 * @dev XiaoC
 * @date 2023/08/25
 */
class CloudCommand : Command("cloud") {
    override fun execute(args: Array<String>) {
        if (args.size >= 2) {
            val command = args[1]

            when (command) {
                // 修改 "list" 命令以从指定 URL 获取配置列表并打印到聊天框
                "list" -> {
                    val url = "http(s)://server.cn/config.php?cfg=list"
                    val content = fetchUrlContent(url)
                    chat("配置列表: $content")
                }
            }
        } else {
            chatSyntax(".cloud < list / load <配置名>")
        }
        "load"
        if (args.size == 3) {
            try {
                val configName = args[2]
                val url = "http(s)://server.cn/config.php?=$configName"
                val content = fetchUrlContent(url)

                val jsonObject = JsonParser().parse(content) as JsonObject

                for (set in jsonObject.entrySet()) {
                    val key = set.key
                    val value = set.value

                    when {
                        key.equals("CommandPrefix", ignoreCase = true) -> {
                            LiquidBounce.commandManager.prefix = value.asCharacter
                        }

                        key.equals("targets", ignoreCase = true) -> {
                            val jsonValue = value as JsonObject
                            EntityUtils.targetPlayer = jsonValue["TargetPlayer"].asBoolean
                            EntityUtils.targetMobs = jsonValue["TargetMobs"].asBoolean
                            EntityUtils.targetAnimals = jsonValue["TargetAnimals"].asBoolean
                            EntityUtils.targetInvisible = jsonValue["TargetInvisible"].asBoolean
                            EntityUtils.targetDead = jsonValue["TargetDead"].asBoolean
                        }

                        key.equals("features", ignoreCase = true) -> {
                            val jsonValue = value as JsonObject
                            AntiForge.enabled = jsonValue["AntiForge"].asBoolean
                            AntiForge.blockFML = jsonValue["AntiForgeFML"].asBoolean
                            AntiForge.blockProxyPacket = jsonValue["AntiForgeProxy"].asBoolean
                            AntiForge.blockPayloadPackets = jsonValue["AntiForgePayloads"].asBoolean
                            BungeeCordSpoof.enabled = jsonValue["BungeeSpoof"].asBoolean
                            delay = jsonValue["AutoReconnectDelay"].asInt
                        }

                        key.equals("thealtening", ignoreCase = true) -> {
                            val jsonValue = value as JsonObject
                            apiKey = jsonValue["API-Key"].asString
                        }

                        else -> {
                            val module = LiquidBounce.moduleManager.getModule(key)
                            if (module != null) {
                                val jsonModule = value as JsonObject
                                module.state = jsonModule["State"].asBoolean
                                module.keyBind = jsonModule["KeyBind"].asInt
                                if (jsonModule.has("Array")) module.array = jsonModule["Array"].asBoolean
                                for (moduleValue in module.values) {
                                    val element = jsonModule[moduleValue.name]
                                    if (element != null) moduleValue.fromJson(element)
                                }
                            }
                        }
                    }
                }

                chat("已加载配置文件: $configName")
            } catch (e: Throwable) {
                chat("无法加载配置文件: ${args[2]}")
            }
        }
    }

    private fun fetchUrlContent(url: String): String {
        val connection = URL(url).openConnection()
        val reader = BufferedReader(InputStreamReader(connection.getInputStream()))
        val content = reader.readText()
        reader.close()
        return content
    }
}