package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL
import kotlin.concurrent.thread

@ModuleInfo(name = "XiaoChat", description = "IRCByXiaoC", category = ModuleCategory.MISC)
class XiaoChat : Module() {

    private var monitoringThread: Thread? = null
    private var lastContent = ""

    override fun onEnable() {
        monitoringThread = thread(start = true) {
            while (state) {
                val currentContent = fetchContent("http://111.67.199.222:1314/irc.php")
                if (currentContent != lastContent) {
                    lastContent = currentContent
                    val parts = currentContent.split("|")
                    if (parts.size >= 4) {
                        val gamename = parts[2]
                        val msg = parts[3]
                        val output = "§c[XiaoChat] §f$gamename: §9$msg"
                        ClientUtils.displayChatMessage(output)
                    }
                }
                Thread.sleep(5000) // Sleep for 5 seconds before checking again
            }
        }
    }

    override fun onDisable() {
        monitoringThread?.interrupt()
        monitoringThread = null
    }

    private fun fetchContent(url: String): String {
        return try {
            val connection = URL(url).openConnection()
            connection.setRequestProperty("Accept-Charset", "UTF-8")
            val reader = BufferedReader(InputStreamReader(connection.getInputStream(), "UTF-8"))
            val content = reader.readText()

            val endIndex = content.indexOf("</div>")
            if (endIndex != -1) {
                content.substring(0, endIndex)
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }





    // 添加一个发送 HTTP 请求的方法
    fun sendHttpRequest(url: String): String {
        return try {
            val connection = URL(url).openConnection()
            connection.setRequestProperty("Accept-Charset", "UTF-8")
            val content = connection.getInputStream().bufferedReader(Charsets.UTF_8).readText()
            content.trim()
        } catch (e: Exception) {
            ""
        }
    }

}
