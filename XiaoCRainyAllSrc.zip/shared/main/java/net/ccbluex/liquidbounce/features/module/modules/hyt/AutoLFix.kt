 package net.ccbluex.liquidbounce.features.module.modules.combat;

import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase
import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.TextValue

 @ModuleInfo(name = "AutoLFix", description = "AutoL", category = ModuleCategory.COMBAT)
class AutoLFix : Module() {
    private val L = BoolValue ("L", true)
    private val AutoLmsg = TextValue("AutoLmsg", "@[Rainy]")

    // Target
    var target: IEntityLivingBase? = null
    var kill = 0
    private fun runAttack() {
        target ?: return
        target = null
    }

    @EventTarget
    fun onAttack(event: AttackEvent) {
        target = event.targetEntity as IEntityLivingBase?
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {

        if (target != null && target!!.isDead) {
            kill+=1
            if (L.get()) {
                mc.thePlayer!!.sendChatMessage(AutoLmsg.get() + "我\uFFF0已\uFFF1经\uFFF2击\uFFF3杀\uFFF4了" + kill + "\uFFF5人" + randomStr())
            }
            target = null
        }


    }

     private fun randomStr(): String {
         // 生成随机字符串 绕过华语图伺服器的特征码16
         val dictChars = mutableListOf<Char>().apply { "\uFFF0\uFFF1\uFFF2\uFFF3\uFFF4\uFFF5\uFFF6\uFFF7\uFFF8\uFFF9\uFFFA\uFFFB\uFFFC\uFFFD\uFFFE\uFFFF".forEach { this.add(it) } }
         return StringBuilder().apply { (1..((5..10).random())).onEach { append(dictChars.random()) } }.toString()
     }

    override val tag: String?
        get() = "Kill $kill"
}
