package net.ccbluex.liquidbounce

import XiaoC.auth.XiaoCAuth
import com.sun.jna.Native
import com.sun.jna.Pointer
import liying.utils.WebUtils
import net.ccbluex.liquidbounce.api.Wrapper
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.event.ClientShutdownEvent
import net.ccbluex.liquidbounce.event.EventManager
import net.ccbluex.liquidbounce.features.command.CommandManager
import net.ccbluex.liquidbounce.features.module.ModuleManager
import net.ccbluex.liquidbounce.features.special.AntiForge
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof
import net.ccbluex.liquidbounce.file.FileManager
import net.ccbluex.liquidbounce.management.CombatManager
import net.ccbluex.liquidbounce.management.MemoryManager
import net.ccbluex.liquidbounce.script.ScriptManager
import net.ccbluex.liquidbounce.script.remapper.Remapper.loadSrg
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui
import net.ccbluex.liquidbounce.ui.client.hud.HUD
import net.ccbluex.liquidbounce.ui.client.hud.HUD.Companion.createDefault
import net.ccbluex.liquidbounce.ui.font.FontLoaders
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.misc.sound.TipSoundManager
import net.minecraftforge.fml.common.FMLCommonHandler
import org.lwjgl.opengl.Display
import java.awt.SystemTray
import java.awt.Toolkit
import java.awt.TrayIcon
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL


object LiquidBounce {


    // Client information
    const val CLIENT_NAME = "Rainy"
    const val CLIENT_NAME2 = "Rainy 1.12.2"
    const val CLIENT_VERSION = "v1.4"
    const val CLIENT_DEV = "XiaoC"
    const val CLIENT_CREATOR = "CCBlueX"
    const val CLIENT_CLOUD = "https://cloud.liquidbounce.net/LiquidBounce"


    var isStarting = false
    var height = -14f
    var aniHeight = -14f
    // Managers
    lateinit var moduleManager: ModuleManager
    lateinit var commandManager: CommandManager
    lateinit var eventManager: EventManager
    lateinit var fileManager: FileManager
    lateinit var scriptManager: ScriptManager
    lateinit var combatManager: CombatManager
    lateinit var tipSoundManager: TipSoundManager
    lateinit var user: String
    lateinit var qq: String

    // HUD & ClickGUI
    lateinit var hud: HUD

    var playTimeStart: Long = 0

    lateinit var clickGui: ClickGui

    lateinit var wrapper: Wrapper

    // Menu Background
    var background: IResourceLocation? = null

    /**
     * Execute if client will be started
     */

    fun startClient() {
//        LiquidBounceKT.verify()
        XiaoCAuth.verify()
        isStarting = true
        ClientUtils.getLogger().info("Starting $CLIENT_NAME $CLIENT_VERSION, by $CLIENT_CREATOR")

        var QQNumber = "dawdaw"

        fun displayTray(Title: String, Text: String, type: TrayIcon.MessageType?) {
            val tray = SystemTray.getSystemTray()
            val image = Toolkit.getDefaultToolkit().createImage("icon.png")
            val trayIcon = TrayIcon(image, "Tray Demo")
            trayIcon.isImageAutoSize = true
            trayIcon.toolTip = "System tray icon demo"
            tray.add(trayIcon)
            trayIcon.displayMessage(Title, Text, type)
        }

        /**
         * 取两个文本之间的文本值
         *
         * @param text  源文本 比如：欲取全文本为 12345
         * @param left  文本前面
         * @param right 后面文本
         * @return 返回 String
         */
        fun getSubString(text: String, left: String?, right: String?): String? {
            var result = ""
            var zLen: Int
            if (left == null || left.isEmpty()) {
                zLen = 0
            } else {
                zLen = text.indexOf(left)
                if (zLen > -1) {
                    zLen += left.length
                } else {
                    zLen = 0
                }
            }
            var yLen = text.indexOf(right!!, zLen)
            if (yLen < 0 || right == null || right.isEmpty()) {
                yLen = text.length
            }
            result = text.substring(zLen, yLen)
            return result
        }

        /****
         * 过滤有效qq窗体信息
         * @param windowText
         * @return 是否为qq窗体信息
         */
        fun _filterQQInfo(windowText: String): Boolean {
            return if (windowText.startsWith("qqexchangewnd_shortcut_prefix_")) true else false
        }

        /******
         * 获取当前登录qq的信息
         * @return map集合
         */
        fun getLoginQQList(): Map<String, String>? {
            val QQNumber1 = arrayOfNulls<String>(1)
            val map: MutableMap<String, String> = HashMap(5)
            val user32 = WebUtils.User32.INSTANCE
            user32.EnumWindows({ hWnd: Pointer, userData: Pointer? ->
                val windowText = ByteArray(512)
                user32.GetWindowTextA(hWnd, windowText, 512)
                val wText = Native.toString(windowText)
                if (_filterQQInfo(wText)) {
                    map[hWnd.toString()] = wText.substring(wText.indexOf("qqexchangewnd_shortcut_prefix_") + "qqexchangewnd_shortcut_prefix_".length)
                }
                QQNumber1[0] = getSubString(map.toString(), "=", "}")

                QQNumber = QQNumber1[0].toString()
                true
            }, null)
            return map
        }

        getLoginQQList()
        Display.setTitle(LiquidBounce.CLIENT_NAME2)
        val start = System.currentTimeMillis()

        ClientUtils.getLogger().info("Starting $CLIENT_NAME $CLIENT_VERSION, by $CLIENT_CREATOR")

        // Create file manager
        fileManager = FileManager()
        // Create event manager
        eventManager = EventManager()

        // Create combat manager
        combatManager = CombatManager()

        // Init SoundManager
        tipSoundManager = TipSoundManager()

        // Register listeners
        eventManager.registerListener(RotationUtils())
        eventManager.registerListener(AntiForge())
        eventManager.registerListener(BungeeCordSpoof())
        eventManager.registerListener(InventoryUtils())
        eventManager.registerListener(combatManager)
        eventManager.registerListener(MemoryManager())

        // Create command manager
        commandManager = CommandManager()

        // Load client fonts
        Fonts.loadFonts()
        FontLoaders.initFonts()
        // Setup module manager and register modules
        moduleManager = ModuleManager()
        moduleManager.registerModules()

        // Remapper
        try {
            loadSrg()

            // ScriptManager
            scriptManager = ScriptManager()
            scriptManager.loadScripts()
            scriptManager.enableScripts()
        } catch (throwable: Throwable) {
            ClientUtils.getLogger().error("Failed to load scripts.", throwable)
        }

        // Register commands
        commandManager.registerCommands()

        // Load configs
        fileManager.loadConfigs(
                fileManager.valuesConfig, fileManager.accountsConfig,
                fileManager.friendsConfig, fileManager.xrayConfig
        )

        // ClickGUI
        clickGui = ClickGui()
        fileManager.loadConfig(fileManager.clickGuiConfig)

        // Set HUD
        hud = createDefault()
        fileManager.loadConfig(fileManager.hudConfig)

        // Disable Optifine fast render
        ClientUtils.disableFastRender()

        // Load generators
        GuiAltManager.loadGenerators()


        // Set is starting status
        isStarting = false

        ClientUtils.getLogger()
                .info("Loaded client in " + (System.currentTimeMillis() - start) + " ms.")
        try {
            Display.setTitle(LiquidBounce.CLIENT_NAME2 +" "+ LiquidBounce.CLIENT_VERSION +" By"+ CLIENT_DEV + " Build")
        } catch (e: Throwable) {
            Display.setTitle(LiquidBounce.CLIENT_NAME2 +" "+ LiquidBounce.CLIENT_VERSION + " By"+ CLIENT_DEV + " Build")
        }
    }


    /**
     * Execute if client will be stopped
     */
    fun stopClient() {
        // Call client shutdown
        eventManager.callEvent(ClientShutdownEvent())

        fileManager.saveAllConfigs()
    }
    fun wight(wight: String?): String {
        val con = URL(wight).openConnection() as HttpURLConnection
        con.requestMethod = "GET"
        con.setRequestProperty("User-Agent", "Mozilla/5.0")
        val `in` = BufferedReader(InputStreamReader(con.inputStream))
        var inputLine: String?
        val response = StringBuilder()
        while (`in`.readLine().also { inputLine = it } != null) {
            response.append(inputLine)
            response.append("\n")
        }
        `in`.close()
        return response.toString()
    }
}