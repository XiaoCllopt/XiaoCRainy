package XiaoC.auth

import XiaoC.utils.QQUtils
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.*

object XiaoCAuth {
    fun verify() {
        QQUtils.getLoginQQList()
        val qq = QQUtils.QQNumber ?: "0"
        val cpuid = cpuid()

        try {
            val key = get("http(s)://server.cn/verify.php?qq=$qq&cpuid=$cpuid")
            
            if (key != cpuid) {
                System.exit(0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            System.exit(0)
        }
    }

    fun cpuid(): String {
        val process = Runtime.getRuntime().exec(arrayOf("wmic", "cpu", "get", "ProcessorId"))
        process.outputStream.close()

        val sc = Scanner(process.inputStream)
        val cpuid = sc.next()

        return md5(cpuid)
    }

    fun get(url: String): String {
        val con = URL(url).openConnection() as HttpURLConnection

        con.requestMethod = "GET"
        con.setRequestProperty("User-Agent", "Mozilla/5.0")

        val inStream = BufferedReader(InputStreamReader(con.inputStream))
        val response = StringBuilder()
        var inputLine: String?

        while (inStream.readLine().also { inputLine = it } != null) {
            response.append(inputLine)
        }

        inStream.close()
        return response.toString()
    }
    
    fun md5(text: String): String {
        val digest = MessageDigest.getInstance("MD5")
        val hashBytes = digest.digest(text.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }
}
