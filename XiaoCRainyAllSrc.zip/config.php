<?php
// 获取传入的cfg参数
$cfg = isset($_GET['cfg']) ? $_GET['cfg'] : '';

// 如果cfg参数为list，则列出Configs文件夹中的所有文件名，用 | 分隔
if ($cfg === 'list') {
    $configFiles = glob('Configs/*');
    $fileNames = array_map('basename', $configFiles);
    echo implode(' | ', $fileNames);
}

// 如果cfg参数为Configs文件夹中的文件名，显示该文件的内容
elseif (file_exists('Configs/' . $cfg)) {
    $fileContents = file_get_contents('Configs/' . $cfg);
    echo $fileContents;
}

// 如果参数不匹配，返回错误或其他操作
else {
    echo 'Invalid cfg parameter or file not found.';
}
?>